import { useState } from 'react';
import { lovable } from '@/integrations/lovable/index';
import { BookOpen, Brain, MessageCircle, Video } from 'lucide-react';

const features = [
  { icon: BookOpen,      label: 'Cours',        desc: 'Ressources pédagogiques' },
  { icon: Brain,         label: 'Exercices IA',  desc: 'Pratique intelligente'   },
  { icon: MessageCircle, label: 'Communauté',    desc: 'Entraide étudiante'      },
  { icon: Video,         label: 'Vidéothèque',   desc: 'Cours en vidéo'          },
];

export function GoogleLoginButton() {
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    const { error } = await lovable.auth.signInWithOAuth('google', {
      redirect_uri: window.location.origin,
    });
    if (error) {
      console.error('Google login error:', error);
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-sm mx-auto flex flex-col items-center gap-6 p-6 animate-fade-in">

      {/* Logo + titre */}
      <div className="text-center space-y-3">
        <div className="w-16 h-16 rounded-2xl gradient-bg flex items-center justify-center text-primary-foreground font-heading font-bold text-2xl mx-auto shadow-lg">
          U
        </div>
        <div>
          <h1 className="font-heading font-bold text-2xl gradient-text">UniLearn</h1>
          <p className="text-muted-foreground text-sm mt-1">Plateforme étudiante CNTEMAD</p>
        </div>
      </div>

      {/* Grille des 4 fonctionnalités */}
      <div className="grid grid-cols-2 gap-2 w-full">
        {features.map(({ icon: Icon, label, desc }) => (
          <div key={label}
            className="flex flex-col gap-1 p-3 rounded-xl bg-secondary/60 border border-border/50 hover:border-primary/30 transition-colors">
            <Icon size={18} className="text-primary" />
            <span className="text-xs font-semibold text-foreground leading-tight">{label}</span>
            <span className="text-[10px] text-muted-foreground leading-tight">{desc}</span>
          </div>
        ))}
      </div>

      {/* Bouton Google */}
      <button onClick={handleLogin} disabled={loading}
        className="w-full flex items-center justify-center gap-3 px-6 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 active:scale-95 transition-all disabled:opacity-50 shadow-md shadow-primary/25">
        {loading ? (
          <>
            <div className="animate-spin w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full" />
            Connexion en cours…
          </>
        ) : (
          <>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Se connecter avec Google
          </>
        )}
      </button>

      <p className="text-[11px] text-muted-foreground text-center leading-relaxed">
        En vous connectant, vous acceptez d'utiliser vos informations Google uniquement pour authentification.
      </p>
    </div>
  );
}
